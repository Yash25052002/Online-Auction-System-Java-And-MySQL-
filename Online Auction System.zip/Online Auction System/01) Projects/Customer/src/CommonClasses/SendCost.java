package CommonClasses;

import java.io.Serializable;

public class SendCost implements Serializable{

	private static final long serialVersionUID = -8430274286975286930L;
	public String Consumer_Name;
	public int cost,ID,Consumer_ID;
}