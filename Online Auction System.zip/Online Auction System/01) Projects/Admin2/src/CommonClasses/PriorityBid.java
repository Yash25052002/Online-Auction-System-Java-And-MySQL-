package CommonClasses;

public class PriorityBid {
	
	public SendBidStatus bid;
	public int priority;
	public PriorityBid(SendBidStatus bid,int I)
	{
		this.bid=bid;
		this.priority=I;
	}

}