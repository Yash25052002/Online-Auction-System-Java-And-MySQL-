package CommonClasses;

import java.io.Serializable;

public class SendCurrentItem implements Serializable{

	private static final long serialVersionUID = 7444525766555540997L;
	public String Time;
	public int ID;
}
