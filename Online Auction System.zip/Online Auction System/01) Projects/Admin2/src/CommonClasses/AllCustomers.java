package CommonClasses;

import java.io.Serializable;
import java.util.Vector;

public class AllCustomers implements Serializable{

	private static final long serialVersionUID = -8460663424815643048L;
	public Vector<CustomerInfo> info;
}