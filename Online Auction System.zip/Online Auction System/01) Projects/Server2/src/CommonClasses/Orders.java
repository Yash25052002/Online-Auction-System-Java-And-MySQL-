package CommonClasses;

import java.io.Serializable;
import java.util.Vector;

public class Orders implements Serializable{

	private static final long serialVersionUID = -3287307085369599113L;
	
	public int Customer_Id;
	public Vector<Integer> v;
}